import React, { useState } from 'react';
import { createRoot } from 'react-dom/client';
import './index.css';

const root = createRoot(document.querySelector('#root'));

root.render(
  <React.StrictMode>
    <header>
      <h1>Shopping Cart</h1>
    </header>

    <main>
      <ProductList />
    </main>

    <footer>
      <p>&copy; 2023 Acne Studios</p>
    </footer>
  </React.StrictMode>
);

function ProductList() {
  const products = [
    {
      id: 'scarf',
      name: 'Vally fringed felt scarf',
      price: 310,
      image:
        'https://www.net-a-porter.com/variants/images/1647597288836087/in/w920_q60.jpg',
    },
    {
      id: 'jeans',
      name: 'Distressed Cargo Jeans',
      price: 950,
      image:
        'https://www.net-a-porter.com/variants/images/1647597290255862/in/w920_q60.jpg',
    },
    {
      id: 'jacket',
      name: 'Coated Bomber Jacket',
      price: 800,
      image:
        'https://www.acnestudios.com/dw/image/v2/AAXV_PRD/on/demandware.static/-/Sites-acne-product-catalog/default/dw46b4bc2e/images/A9/A90570-/2000x/A90570-A*M_F.jpg?sw=1500&sh=2250',
    },
    {
      id: 'sweater',
      name: 'Distressed knitted sweater',
      price: 294,
      image:
        'https://www.net-a-porter.com/variants/images/1647597290260156/in/w920_q60.jpg',
    },
  ];

  return (
    <div className="product-list">
      {products.map((product) => (
        <Product
          key={product.id}
          name={product.name}
          price={product.price}
          image={product.image}
        />
      ))}
    </div>
  );
}

// item counter
// var count: 0;
function Product(props) {
  const [count, setCount] = useState(0);

  // decrement product count by 1
  // no negative values: (count > 0);
  const handleMinusClick = () => {
    if (count > 0) {
      setCount(count - 1);
      console.log('minus button clicked');
    }
  };

  // increment product count by 1
  const handlePlusClick = () => {
    setCount(count + 1);
    console.log('plus button clicked');
  };

  return (
    <div className="product">
      <img src={props.image} alt={props.name} />
      <h2>{props.name}</h2>
      <div className="price-container">
        <p>${props.price}</p>
        <div className="counter">
          <button onClick={handleMinusClick}>-</button>
          <span>{count}</span>
          <button onClick={handlePlusClick}>+</button>
        </div>
      </div>
    </div>
  );
}

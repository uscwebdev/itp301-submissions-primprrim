import React from 'react';
import { useState } from 'react';

export default function Form() {
  const [fullname, setFullName] = useState('');
  const [password, setPassword] = useState('');
  const [confirmpassword, setConfirmPassword] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [comments, setComments] = useState('');
  const [terms, setTerms] = useState(false);
  const [commentCount, setCommentCount] = useState(0);

  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;

    if (name === 'full-name') {
      setFullName(value);
      console.log('Full Name:', value);
    }

    if (name === 'password') {
      setPassword(value);
      console.log('Password:', value);
    }

    if (name === 'password-confirm') {
      setConfirmPassword(value);
      console.log('Confirm Password:', value);
    }

    if (name === 'email') {
      setEmail(value);
      console.log('Email:', value);
    }

    if (name === 'phone') {
      setPhone(value);
      console.log('Phone:', value);
    }

    if (name === 'comment') {
      setComments(value);
      setCommentCount(value.length);

      console.log('Comments:', value);
      console.log('val length', commentCount);
    }

    if (name === 'terms') {
      setTerms(checked);
      console.log('Terms:', checked);
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();

    const isFormValid = validateForm();

    if (isFormValid) {
      console.log({
        fullname,
        password,
        confirmpassword,
        email,
        phone,
        comments,
        terms,
      });
      alert('Registration Successful');
    }
  };

  const validateForm = () => {
    const errors = [];

    if (fullname.trim() === '') {
      errors.push('Name cannot be empty.');
    } else if (!/\s/.test(fullname)) {
      errors.push('You must provide a full name.');
    }

    if (password.trim() === '') {
      errors.push('Password cannot be empty.');
    } else if (password.length < 5) {
      errors.push('Password must contain at least 5 characters.');
    } else if (!/[a-z]/.test(password) || !/[A-Z]/.test(password)) {
      errors.push(
        'Password must contain both uppercase and lowercase characters.'
      );
    }

    if (confirmpassword !== password) {
      errors.push('Passwords do not match.');
    }

    if (email.trim() === '' && phone.trim() === '') {
      errors.push('You must provide either email or phone.');
    }

    if (comments.length > 100) {
      errors.push('Comments cannot exceed 100 characters.');
    }

    if (!terms) {
      errors.push('You must accept Terms & Conditions.');
    }

    if (errors.length > 0) {
      alert(errors.join('\n'));
      return false;
    } else {
      alert('Registration Successful');
      return true;
    }
  };

  return (
    <div className="container my-3">
      <div className="row">
        <div className="col-12">
          <form onSubmit={handleSubmit}>
            <div className="my-3 row">
              <label htmlFor="full-name" className="col-sm-2 col-form-label">
                Full Name: <span className="text-danger">*</span>
              </label>
              <div className="col-sm-10">
                <input
                  type="text"
                  className="form-control"
                  placeholder="Tommy Trojan"
                  id="full-name"
                  onChange={handleChange}
                  name="full-name"
                />
              </div>
            </div>

            <div className="my-3 row">
              <label htmlFor="password" className="col-sm-2 col-form-label">
                Password: <span className="text-danger">*</span>
              </label>
              <div className="col-sm-10">
                <input
                  type="password"
                  className="form-control"
                  id="password"
                  onChange={handleChange}
                  name="password"
                />
              </div>
            </div>

            <div className="my-3 row">
              <label
                htmlFor="password-confirm"
                className="col-sm-2 col-form-label"
              >
                Confirm Password: <span className="text-danger">*</span>
              </label>
              <div className="col-sm-10">
                <input
                  type="password"
                  className="form-control"
                  id="password-confirm"
                  onChange={handleChange}
                  name="password-confirm"
                />
              </div>
            </div>

            <div className="my-3 row">
              <label className="col-sm-2 col-form-label">
                Provide One: <span className="text-danger">*</span>
              </label>
              <div className="col-10">
                <div className="row">
                  <label htmlFor="email" className="col-sm-2 col-form-label">
                    Email:
                  </label>
                  <div className="col-sm-10">
                    <input
                      type="text"
                      className="form-control"
                      placeholder="ttrojan@usc.edu"
                      id="email"
                      onChange={handleChange}
                      name="email"
                    />
                  </div>

                  <label
                    htmlFor="phone"
                    className="mt-sm-2 col-sm-2 col-form-label"
                  >
                    Phone:
                  </label>
                  <div className="mt-sm-2 col-sm-10">
                    <input
                      type="text"
                      className="form-control"
                      placeholder="(123) 456-7890"
                      id="phone"
                      onChange={handleChange}
                      name="phone"
                    />
                  </div>
                </div>
              </div>
            </div>

            <div className="my-3 row">
              <label htmlFor="comment" className="col-sm-2 col-form-label">
                Comments:
              </label>
              <div className="col-sm-10">
                <textarea
                  className="form-control"
                  id="comment"
                  onChange={handleChange}
                  name="comment"
                ></textarea>

                <small id="comment-count" className="form-text text-right">
                  {commentCount} / 100
                </small>
              </div>
            </div>

            <div className="my-3 row">
              <label className="col-sm-2 col-form-label"></label>
              <div className="col-sm-10">
                <div className="form-check form-check-inline">
                  <input
                    className="form-check-input"
                    type="checkbox"
                    id="terms"
                    onChange={handleChange}
                    name="terms"
                  />
                  <label className="form-check-label" htmlFor="terms">
                    I accept Terms & Conditions.
                    <span className="text-danger">*</span>
                  </label>
                </div>
              </div>
            </div>

            <div className="my-3 row">
              <div className="col-sm-10">
                <button type="submit" className="btn btn-primary">
                  Register
                </button>
              </div>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
}

import React from 'react';
import { createRoot } from 'react-dom/client';
import './index.css';

const root = createRoot(document.querySelector('#root'));

root.render(
  <React.StrictMode>
    <h1>prim boonyachai</h1>

    <div class="email">
      <a href="boonyach@usc.edu">boonyach@usc.edu</a>
    </div>

    <div class="fav-color">
      <p>light caramel</p>
    </div>

    <div class="fav-web">
      <a href="https://becomingamorningperson.com/">
        marine buffard's becoming a morning person
      </a>
    </div>

    <div class="fav-activity">
      <img
        src="https://64.media.tumblr.com/8cadc6329c0b7c676a4f646f5dd2f34f/84c6faddc8644c08-87/s1280x1920/66b85fca326ec08e7552048b05d01bbd47cf77f0.jpg"
        alt="cafe-hopping"
      />
      <p>fav activity: cafe-hopping</p>
    </div>

    <div id="classes">
      <ul>
        <li>des 230: 3d design - materials and tools</li>
        <li>des 302: design III</li>
        <li>des 303: web design</li>
        <li>des 332a: typography a</li>
        <li>itp 301: front-end web development</li>
      </ul>
    </div>
  </React.StrictMode>
);

import React, { useState } from 'react';

export default function PhotoGallery() {
  const [currentImage, setCurrentImage] = useState({
    src: 'https://www.heathceramics.com/cdn/shop/files/Heath_W23_BudVase_130_0551_7890_web_440x440_crop_center.jpg?v=1695149119',
    alt: 'Bud Vase in Myrtle Green',
    caption: 'Bud Vase In Myrtle Green',
  });

  function changeImage(newSrc, newAlt, newCaption) {
    setCurrentImage({
      src: newSrc,
      alt: newAlt,
      caption: newCaption,
    });
  }

  return (
    <div>
      <h1>Cermaic Photo Gallery</h1>
      <div id="image-container">
        <img id="main-image" src={currentImage.src} alt={currentImage.alt} />
        <p id="image-caption">{currentImage.caption}</p>
      </div>
      <div id="buttons">
        <button
          onClick={() =>
            changeImage(
              'https://www.heathceramics.com/cdn/shop/files/Heath_W23_BudVase_130_0551_7890_web_440x440_crop_center.jpg?v=1695149119',
              'Image 1',
              'Bud Vase in Myrtle Green'
            )
          }
        >
          Image 1
        </button>
        <button
          onClick={() =>
            changeImage(
              'https://www.heathceramics.com/cdn/shop/products/bulb-vase-indigo-heath-ceramics_131-0250_440x440_crop_center.jpg?v=1665001448',
              'Image 2',
              'Bulb Vase'
            )
          }
        >
          Image 2
        </button>
        <button
          onClick={() =>
            changeImage(
              'https://www.heathceramics.com/cdn/shop/products/20230111_HeathCeramics_132-0611_3987_440x440_crop_center.jpg?v=1679436640',
              'Image 3',
              'Single-Stem Vase in Landscape'
            )
          }
        >
          Image 3
        </button>
        <button
          onClick={() =>
            changeImage(
              'https://www.heathceramics.com/cdn/shop/products/single-stem-vase-indigo-heath-ceramics_132-0250_440x440_crop_center.jpg?v=1667435914',
              'Image 4',
              'Single-Stem Vase'
            )
          }
        >
          Image 4
        </button>
        <button
          onClick={() =>
            changeImage(
              'https://www.heathceramics.com/cdn/shop/files/WEB_20230526_HEATH5604-HCS-NKVT-0655_440x440_crop_center.jpg?v=1687290086',
              'Image 5',
              'Tall Neck Vase in Sunflower Gloss & Opaque White'
            )
          }
        >
          Image 5
        </button>
      </div>
    </div>
  );
}

import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import FormModal from './formModal';

export default function HomePage() {
  const restaurantReviews = [
    {
      name: 'camphor',
      description: 'french ',
      address: '923 E 3rd St #109',
      image:
        'https://res.cloudinary.com/the-infatuation/image/upload/v1656116347/cms/camphor/JakobLayman.Camphor_023.jpg',
    },
    {
      name: 'jemma di mare',
      description: 'italian',
      address: '11677 San Vicente Blvd #200',
      image:
        'https://cdn.vox-cdn.com/thumbor/tPrl3adlhdFfoBK7ZqWSEeElMos=/0x0:2000x1333/1200x675/filters:focal(840x507:1160x827)/cdn.vox-cdn.com/uploads/chorus_image/image/72239499/2023_04_25_JemmaDiMare_026.0.jpg',
    },
    {
      name: 'bicyclette',
      description: 'french',
      address: '9575 W Pico Blvd',
      image:
        'https://res.cloudinary.com/the-infatuation/image/upload/v1656121572/cms/reviews/pasjoli/JakobLayman.Pasjoli.Group_025.jpg',
    },
    {
      name: 'petit trois',
      description: 'french',
      address: '718 N Highland Ave',
      image:
        'https://freight.cargo.site/t/original/i/3d104c24c8031000067c3a228866e2eacbdb6076cb15d111a3fc6946caa160f7/GoatFish_LA-PetitTrois-1322.jpg',
    },
    {
      name: 'kuya lord',
      description: 'filipino',
      address: '5003 Melrose Ave',
      image:
        'https://kuyalord.com/wp-content/uploads/2022/04/JakobLayman.0222.KuyaLord_496-1024x683.jpg',
    },
    {
      name: 'izakaya osen',
      description: 'japanese',
      address: '2903 Sunset Blvd',
      image:
        'https://images.squarespace-cdn.com/content/v1/5897c806bf629a11b28aad33/1694558494789-DNEUMRBXI4B45SCIYJPU/Sashimi+Omakase01.jpeg?format=2500w',
    },
  ];

  const [isModalOpen, setIsModalOpen] = useState(false);

  const openModal = () => {
    setIsModalOpen(true);
  };

  const closeModal = () => {
    setIsModalOpen(false);
  };

  const [isButtonHovered, setIsButtonHovered] = useState(false);

  const navigate = useNavigate();

  const handleExploreClick = (restaurant) => {
    navigate(`/reviews/${restaurant.name.toLowerCase()}`, {
      state: { restaurant },
    });
  };

  return (
    <div>
      <section id="home">
        <div className="hero">
          <h1>the diner diary</h1>
          <p>unmasking the culinary wonders of los angeles.</p>
        </div>
      </section>

      <section id="reviews">
        <h2>reviews</h2>
        <button id="feedback" onClick={openModal}>
          Share Your Feedback
        </button>
        <FormModal isOpen={isModalOpen} onClose={closeModal} />
        <div className="review-cards">
          {restaurantReviews.map((review, index) => (
            <div key={index} className="review-card">
              <img
                src={review.image}
                alt={`${review.name} restaurant`}
                style={{
                  width: '420px',
                  height: '280px',
                  objectFit: 'cover',
                  borderRadius: '10px 10px 10px 10px',
                  marginBottom: '15px',
                }}
              />
              <div className="review-details">
                <h3>{review.name}</h3>
                <p>{review.description}</p>
                <p>{review.address}</p>
                <button onClick={() => handleExploreClick(review)}>
                  explore
                </button>
              </div>
            </div>
          ))}
        </div>
      </section>

      <hr></hr>

      <section id="about">
        <h2>about us</h2>
        <p>
          the diner diary is your ultimate guide to the eclectic and vibrant
          culinary scene in los angeles! we believe that every meal tells a
          story, and here at the diner diary, we are passionate about sharing
          those tales with fellow food enthusiasts and explorers.
        </p>
        <p>
          expect more than just reviews; think of the diner diary as your foodie
          journal, documenting not just what's on the plate but the ambiance,
          the service, and the unique stories behind each establishment. we're
          here to inspire your next culinary journey, whether you're a local
          looking for something new or a visitor eager to taste the city's
          essence.
        </p>
      </section>
    </div>
  );
}

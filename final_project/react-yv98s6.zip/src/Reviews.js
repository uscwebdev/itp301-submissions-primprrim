import React, { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import ReviewData from './ReviewData';

const Reviews = () => {
  const restaurantName = decodeURIComponent(
    window.location.pathname.split('/reviews/')[1]
  );

  const selectedRestaurant = ReviewData.find(
    (data) => data.name.toLowerCase() === restaurantName.toLowerCase()
  );

  if (!selectedRestaurant) {
    return <div>Loading...</div>;
  }

  return (
    <div>
      <h2 class="review-title">{selectedRestaurant.name}</h2>
      <p class="review-text">cuisine: {selectedRestaurant.description}</p>
      <p class="review-text">address: {selectedRestaurant.address}</p>
      <img
        class="review-image"
        src={selectedRestaurant.image}
        alt={`${selectedRestaurant.name} restaurant`}
        style={{
          width: '850px',
          height: '500px',
          objectFit: 'cover',
          borderRadius: '10px',
        }}
      />
      <p class="review-text">{selectedRestaurant.review1}</p>
      <img
        class="review-image"
        src={selectedRestaurant.reviewImage1}
        alt={`${selectedRestaurant.name} restaurant`}
        style={{
          width: '850px',
          height: '500px',
          objectFit: 'cover',
          borderRadius: '10px',
        }}
      />
      <p class="review-text">{selectedRestaurant.review2}</p>
      <img
        class="review-image"
        src={selectedRestaurant.reviewImage2}
        alt={`${selectedRestaurant.name} restaurant`}
        style={{
          width: '850px',
          height: '500px',
          objectFit: 'cover',
          borderRadius: '10px',
        }}
      />
      <p class="review-text">{selectedRestaurant.review3}</p>
      <img
        class="review-image"
        src={selectedRestaurant.reviewImage3}
        alt={`${selectedRestaurant.name} restaurant`}
        style={{
          width: '850px',
          height: '500px',
          objectFit: 'cover',
          borderRadius: '10px',
        }}
      />
      <p class="review-text">{selectedRestaurant.review4}</p>
      <img
        class="review-image"
        src={selectedRestaurant.reviewImage4}
        alt={`${selectedRestaurant.name} restaurant`}
        style={{
          width: '850px',
          height: '500px',
          objectFit: 'cover',
          borderRadius: '10px',
        }}
      />
      <p id="review-text-1" class="review-text">
        {selectedRestaurant.review5}
      </p>
    </div>
  );
};

export default Reviews;

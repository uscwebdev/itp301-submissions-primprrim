const ReviewData = [
  {
    name: 'camphor',
    description: 'french',
    address: '923 E 3rd St #109',
    image:
      'https://res.cloudinary.com/the-infatuation/image/upload/v1656116347/cms/camphor/JakobLayman.Camphor_023.jpg',
    review1:
      'nestled in the heart of the city, camphor la is a hidden gem that promises an unforgettable culinary journey. from the moment you step inside, you are enveloped in an ambiance that seamlessly blends modern sophistication with warm hospitality.',
    reviewImage1:
      'https://live.staticflickr.com/65535/52173525590_660b121548_b.jpg',
    review2:
      'amuse bouche: an inspired starter, reminiscent of the vibrant flavors of pani puri. the infusion of south-east asian spices and french culinary elements seamlessly harmonizes in this delightful dish, showcasing a brilliant interplay of diverse tastes.',
    reviewImage2:
      'https://res.cloudinary.com/the-infatuation/image/upload/c_fill,w_1200,ar_4:3,g_center,f_auto/cms/camphor/JakobLayman.Camphor_013',
    review3:
      'beef tartare: hands down one of the best tartares I have ever had. the beef itself was well-seasoned with hints of citrus flavors served alongside a plate of deep-fried shiso and parsely leaves.',
    reviewImage3:
      'https://res.cloudinary.com/the-infatuation/image/upload/c_fill,w_1200,ar_4:3,g_center,f_auto/cms/camphor/JakobLayman.Camphor_017',
    review4:
      'chicken: a robust dish that stands as a testament to the mastery of flavors. this savory delight features succulent chicken, expertly prepared and accompanied by a rich, delectable gravy served on the side.',
    reviewImage4:
      'https://cdn.vox-cdn.com/thumbor/LEnCsOLLiB-1deaLs4FtzvYlzE0=/0x0:2000x1333/1920x0/filters:focal(0x0:2000x1333):format(webp):no_upscale()/cdn.vox-cdn.com/uploads/chorus_asset/file/23263592/2022_02_11_Camphor_042.jpg',
    review5:
      'meyer lemon ice marzipan: a tantalizing and refreshing dessert designed to cleanse your palate after a fulfilling meal. this culinary creation seamlessly combines the zesty notes of meyer lemon with the delicate sweetness of marzipan, delivering a harmonious balance that dances on your taste buds. the chilled, citrusy essence of the Meyer lemon ice provides a refreshing contrast, while the velvety marzipan adds a layer of decadence to every spoonful.',
  },
  {
    name: 'jemma di mare',
    description: 'italian',
    address: '11677 San Vicente Blvd #200',
    image:
      'https://cdn.vox-cdn.com/thumbor/tPrl3adlhdFfoBK7ZqWSEeElMos=/0x0:2000x1333/1200x675/filters:focal(840x507:1160x827)/cdn.vox-cdn.com/uploads/chorus_image/image/72239499/2023_04_25_JemmaDiMare_026.0.jpg',
    review1:
      'jemma di Mare is a culinary gem that transports diners to a coastal paradise. from the moment you step into the restaurant, the soothing ambiance and nautical-inspired decor set the stage for a memorable dining experience.',
    reviewImage1:
      'https://popmenucloud.com/cdn-cgi/image/width=1920,height=1920,format=auto,fit=scale-down/privfjck/5d5b002b-a4aa-4c50-a4fb-accef42f2439.jpg',
    review2:
      'smoked trout dip: crafted with the finest smoked trout, this dip boasts a luxurious texture that effortlessly spreads on crisp crackers, creating a harmonious marriage of flavors and textures. the smokiness of the trout is perfectly balanced with the creaminess of the dip, creating a palate-pleasing experience that is both rich and indulgent.',
    reviewImage2:
      'https://cdn.vox-cdn.com/thumbor/FZSqCOreBHPM1BcKRaROap_qKCw=/0x0:2000x1333/1200x0/filters:focal(0x0:2000x1333):no_upscale()/cdn.vox-cdn.com/uploads/chorus_asset/file/24625684/2023_04_25_JemmaDiMare_021.jpg',
    review3:
      'capellini & meatballs: al dente capellini enveloped in a thick, rich sauce, and accompanied by meatballs so dense and chewy, they redefine your expectations. the marriage of the perfectly textured pasta and hearty meatballs creates a symphony of flavors that dance on your palate.',
    reviewImage3:
      'https://popmenucloud.com/cdn-cgi/image/width=1920,height=1920,format=auto,fit=scale-down/privfjck/450217a4-9326-4aec-bb48-17e2c5c8deac.jpg',
    review4:
      'mandilli: thick, velvety pasta elegantly coated in a creamy, almost pesto sauce. the mandilli experience begins with the silkiness of the pasta, perfectly crafted to capture every nuance of the decadent sauce it cradles.',
    reviewImage4:
      'https://popmenucloud.com/cdn-cgi/image/width=1200,height=630,format=auto,fit=cover/privfjck/a40e6f11-96a0-4145-80c4-7532e77b3148.jpg',
    review5:
      'as you savor the kanpachi siciliana, the interplay of textures and tastes unfolds a gastronomic experience that goes beyond the expected. the richness of the fish, the tanginess of the sauce, and the subtle heat of the chili come together to create a culinary masterpiece that leaves a lasting impression.',
  },
  {
    name: 'bicyclette',
    description: 'french',
    address: '9575 W Pico Blvd',
    image:
      'https://res.cloudinary.com/the-infatuation/image/upload/v1656121572/cms/reviews/pasjoli/JakobLayman.Pasjoli.Group_025.jpg',
    review1:
      'tucked away in the heart of los angeles, bicyclette is a hidden culinary gem that captivates from the moment you enter. the ambiance exudes warmth, with rustic-chic decor and an inviting atmosphere that sets the stage for an extraordinary dining experience.',
    reviewImage1:
      'https://cdn.vox-cdn.com/thumbor/7v_9u6gfYMwTWMHER03CFDJ4j88=/0x0:5727x3823/1720x0/filters:focal(0x0:5727x3823):format(webp):no_upscale()/cdn.vox-cdn.com/uploads/chorus_asset/file/22661063/9.jpg',
    review2:
      'baguette with rodolphe le meunier normandy butter: the dish elevates a simple concept to a realm of unparalleled sophistication. the baguette, a masterpiece of crispiness on the outside and pillowy softness within, serves as the perfect canvas for the star of the show, rodolphe le Meunier normandy butter.',
    reviewImage2:
      'https://cdn.vox-cdn.com/thumbor/VixKq2QqmCwN6Jzux0EuXo3mTuI=/0x0:5420x3618/1720x0/filters:focal(0x0:5420x3618):format(webp):no_upscale()/cdn.vox-cdn.com/uploads/chorus_asset/file/22661030/17.jpg',
    review3:
      'beef short rib a la bourguignon: served atop a bed of velvety mashed potatoes, the beef Short rib a la bourguignon at bicyclette is not merely a meal; it is a culinary masterpiece. the melding of classic french techniques with a creative touch results in a dish that pays homage to tradition while pushing the boundaries of gastronomic delight.',
    reviewImage3:
      'https://cdn.vox-cdn.com/thumbor/xUsjIs8Hc2PiPT42q08dviXX2pM=/0x0:5933x3961/1920x0/filters:focal(0x0:5933x3961):format(webp):no_upscale()/cdn.vox-cdn.com/uploads/chorus_asset/file/22661021/13.jpg',
    review4:
      'rock cod bouillabaisse: this seafood masterpiece encapsulates the essence of the traditional french dish, showcasing the dedication to authenticity and culinary finesse. the rock cod takes center stage in this bouillabaisse, its delicate flesh absorbing the rich flavors of the broth.',
    reviewImage4:
      'https://cdn.vox-cdn.com/thumbor/-1eusNDaEui3XLnYUEYHL7HsgV8=/0x0:5435x3628/1920x0/filters:focal(0x0:5435x3628):format(webp):no_upscale()/cdn.vox-cdn.com/uploads/chorus_asset/file/22661032/15.jpg',
    review5:
      'tarte trio: this indulgent ensemble showcases a masterful fusion of flavors and textures, promising a symphony of sweetness that delights the senses: lemon with blackberries, chocolate with salted caramel, and cherry tarte with pistachios.',
  },
  {
    name: 'petit trois',
    description: 'french',
    address: '718 N Highland Ave',
    image:
      'https://freight.cargo.site/t/original/i/3d104c24c8031000067c3a228866e2eacbdb6076cb15d111a3fc6946caa160f7/GoatFish_LA-PetitTrois-1322.jpg',
    review1:
      'petit trois is a gastronomic haven that beckons with the allure of a parisian bistro, delivering an unforgettable dining experience that transcends expectations. from the moment you step into this charming establishment, the air is infused with an unmistakable sense of culinary passion and expertise.',
    reviewImage1:
      'https://assets.bonappetit.com/photos/5d23b8ec9eb9a600080cf1a4/16:9/w_2496,h_1404,c_limit/Aug-Any-Way-Nicoise-Tuna-alt.jpg',
    review2:
      'niçoise tuna salad: the star of the show is undoubtedly the seared tuna—pristine, ruby-red slices that effortlessly melt in the mouth. the expertly seared exterior gives way to a tender, sushi-grade center, showcasing the commitment to quality seafood. the tuna becomes a canvas for the symphony of flavors that follow.',
    reviewImage2:
      'https://assets.bonappetit.com/photos/57acddf41b33404414975283/master/pass/petit-troiss-french-onion-soup.jpg',
    review3:
      'french onion soup: the first encounter with the soup is a feast for the senses—a blanket of melted gruyère cheese crowning a crock of steaming broth-soaked onions. the aroma alone, a melody of caramelized sweetness and savory richness, whets the appetite and sets the stage for a memorable experience.',
    reviewImage3:
      'https://thelocaltongue.com/wp-content/uploads/2019/11/david-gelb-los-angeles-the-local-tongue.jpg',
    review4:
      'croque madame: served alongside a fresh and crisp side salad, the croque madame at petit trois is not just a meal; it is a celebration of culinary finesse. whether you are a devoted fan of french cuisine or a newcomer to its delights, this dish invites you to revel in the harmonious blend of textures and flavors that defines the essence of a true croque madame. ',
    reviewImage4:
      'https://images.squarespace-cdn.com/content/v1/6418a1976f1b3b6d80d3ebca/98de52b4-6d97-4fdb-b849-12ec82fd84b9/Screen+Shot+2022-04-08+at+2.16.43+PM.png',
    review5:
      'big mec: at first glance, the big mec makes a statement—an architectural marvel of culinary delight. two thin patties, expertly grilled to perfection, are delicately stacked and adorned with a symphony of flavors. the caramelized onions, a testament to patience and precision, impart a sweet and savory note that elevates the burgers complexity.',
  },
  {
    name: 'kuya lord',
    description: 'filipino',
    address: '5003 Melrose Ave',
    image:
      'https://kuyalord.com/wp-content/uploads/2022/04/JakobLayman.0222.KuyaLord_496-1024x683.jpg',
    review1:
      'where culinary excellence meets the soulful flavors of southern tagalog region cuisine. kuya lord is a gastronomic haven curated by Chef Maynard, whose culinary journey has been shaped by a passion for authenticity and a dedication to mastering classic cooking techniques.',
    reviewImage1:
      'https://res.cloudinary.com/the-infatuation/image/upload/c_fill,w_1200,ar_4:3,g_center,f_auto/JakobLayman.KuyaLord_013_ebhgoy',
    review2:
      'kuya tray: at the heart of the kuya tray is the irresistible sticky garlic java rice, a fragrant and savory delight that serves as the perfect canvas for the culinary journey that follows. each grain is infused with the aromatic blend of garlic, creating a harmonious backdrop for the medley of flavors that awaits.',
    reviewImage2:
      'https://res.cloudinary.com/the-infatuation/image/upload/c_fill,w_1200,ar_4:3,g_center,f_auto/JakobLayman.KuyaLord_005_b5qwcl',
    review3:
      'hiramasa collar: grilled to perfection over almond wood, the fish acquires a distinctive flavor profile that sets it apart. served alongside, you will find red chili oil, introducing a subtle heat, and soymansi, a delightful blend of salty and sour notes derived from the harmonious marriage of soy and calamansi juice.',
    reviewImage3:
      'https://res.cloudinary.com/the-infatuation/image/upload/c_fill,w_1200,ar_4:3,g_center,f_auto/JakobLayman.KuyaLord_024_1_sqffb8',
    review4:
      'lucenachon: kuya lord boasts a standout house specialty in the form of a crescent-shaped, rolled pork belly—an absolute must-have on each visit. the pork delights with its succulent and savory qualities, striking a perfect balance of tenderness and just the right amount of fat, ensuring a rich but not overly heavy experience.',
    reviewImage4:
      'https://res.cloudinary.com/the-infatuation/image/upload/c_fill,w_1200,ar_4:3,g_center,f_auto/JakobLayman.KuyaLord_027_f2zka2',
    review5:
      'calamansi pie: this dessert offers a playful twist on the classic key lime pie, incorporating the citrusy goodness of calamansi and crowned with pandan-infused whipped cream, imparting a robust and floral vanilla essence. unlike the heartier portions typical of our other dishes, this dessert is more modest in size, perfectly portioned for sharing between two.',
  },
  {
    name: 'izakaya osen',
    description: 'japanese',
    address: '2903 Sunset Blvd',
    image:
      'https://images.squarespace-cdn.com/content/v1/5897c806bf629a11b28aad33/1694558494789-DNEUMRBXI4B45SCIYJPU/Sashimi+Omakase01.jpeg?format=2500w',
    review1:
      'izakaya osen is a hidden gem that unfolds like a culinary masterpiece. from the moment you step through the door, you are transported to a haven where traditional japanese flavors blend seamlessly with contemporary sophistication.',
    reviewImage1:
      'https://images.squarespace-cdn.com/content/v1/5897c806bf629a11b28aad33/32a353f7-474b-4a83-ad18-8a94314efd2f/kushiyaki.jpg?format=2500w',
    review2:
      'jidori chicken cartilage: served as a delightful snack or a bold appetizer, jidori chicken cartilage is a testament to the culinary philosophy that appreciates every part of the ingredient. the cartilage is expertly seasoned and grilled to a perfect crispiness, creating an irresistible crunch that gives way to a tender and succulent interior.',
    reviewImage2:
      'https://images.squarespace-cdn.com/content/v1/5897c806bf629a11b28aad33/f5dd9a81-25c7-4281-8bc6-bc89d0c87101/salad.jpg?format=2500ws',
    review3:
      'kabocha no nimono: the kabocha squash, sliced into tender, bite-sized pieces, is the star of this nimono (simmered dish). the initial glance reveals a medley of warm, golden hues that invite the diner to experience the comforting essence of the seasonally inspired creation.',
    reviewImage3:
      'https://images.squarespace-cdn.com/content/v1/5897c806bf629a11b28aad33/6270664a-60a5-438b-9f1c-2aadd627dd47/ricebowls.jpg?format=2500w',
    review4:
      'toro uni bowl: indulging in the toro uni bowl is an exquisite journey. a harmonious fusion of chopped tuna belly, creamy sea urchin, scallions, shish leaf, delicate caviar, and a drizzle of sesame oil, all cradled on a bed of perfectly seasoned sushi rice, this bowl is a culinary masterpiece that does not disappoint.',
    reviewImage4:
      'https://images.squarespace-cdn.com/content/v1/5897c806bf629a11b28aad33/7d9e8755-2b57-4926-8041-1efa60656689/2022-12-13-Izakaya_Osen_Irvine-006.jpg?format=2500w',
    review5:
      'osen makimono: this artfully crafted roll features a harmonious blend of bluefin tuna, salmon, and yellowtail delicately wrapped in soy paper, creating a visual feast that sets the stage for an unforgettable dining experience.',
  },
];

export default ReviewData;

import React, { useState, useRef, useEffect } from 'react';
import './modal.css';

const ContactForm = ({ isOpen, onClose }) => {
  const modalRef = useRef(null);

  useEffect(() => {
    const handleOutsideClick = (e) => {
      if (modalRef.current && !modalRef.current.contains(e.target)) {
        onClose();
      }
    };

    if (isOpen) {
      document.addEventListener('mousedown', handleOutsideClick);
    }

    return () => {
      document.removeEventListener('mousedown', handleOutsideClick);
    };
  }, [isOpen, onClose]);

  const [email, setEmail] = useState('');
  const [comments, setComments] = useState('');
  const [isValidEmail, setIsValidEmail] = useState(true);
  const [showEmailError, setShowEmailError] = useState(false);

  const validateEmail = (value) => {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(value);
  };

  const handleSubmit = (e) => {
    e.preventDefault();

    const isValid = validateEmail(email);
    setIsValidEmail(isValid);

    if (isValid) {
      console.log('Email:', email);
      console.log('Comments:', comments);

      onClose();
    } else {
      setShowEmailError(true);
    }
  };

  return (
    <div className={`modal ${isOpen ? 'open' : ''}`}>
      <div className="modal-overlay" onClick={onClose}></div>
      <div className="modal-content" ref={modalRef}>
        <span className="close-button" onClick={onClose}>
          &times;
        </span>
        <h2>Share Your Feedback</h2>
        <form onSubmit={handleSubmit}>
          <label>
            Email:
            <input
              type="text"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
            />
          </label>
          {showEmailError && !isValidEmail && (
            <p className="error-message">Please enter a valid email address</p>
          )}
          <label>
            Comments:
            <textarea
              value={comments}
              onChange={(e) => setComments(e.target.value)}
            />
          </label>
          <button type="submit">Submit</button>
        </form>
      </div>
    </div>
  );
};

export default ContactForm;

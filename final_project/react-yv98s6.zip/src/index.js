import React from 'react';
import { createRoot } from 'react-dom/client';
import { BrowserRouter, Route, Routes } from 'react-router-dom';
import './index.css';
import HomePage from './HomePage';
import Reviews from './Reviews';
import Navbar from './navbar';
import Footer from './footer';

const root = createRoot(document.querySelector('#root'));

root.render(
  <React.StrictMode>
    <BrowserRouter>
      <Navbar />
      <Routes>
        <Route path="/" element={<HomePage />} />
        <Route path="/reviews/:restaurant" element={<Reviews />} />
      </Routes>
      <Footer />
    </BrowserRouter>
  </React.StrictMode>
);

import React from 'react';

const Navbar = () => {
  return (
    <nav>
      <ul>
        <li>
          <a href="/">home</a>
        </li>
        <li>
          <a href="/reviews/camphor">camphor</a>
        </li>
        <li>
          <a href="/reviews/jemma%20di%20mare">jemma di mare</a>
        </li>
        <li>
          <a href="/reviews/bicyclette">bicyclette</a>
        </li>
        <li>
          <a href="/reviews/petit%20trois">petit trois</a>
        </li>
        <li>
          <a href="/reviews/kuya%20lord">kuya lord</a>
        </li>
        <li>
          <a href="/reviews/izakaya%20osen">izakaya osen</a>
        </li>
      </ul>
    </nav>
  );
};

export default Navbar;

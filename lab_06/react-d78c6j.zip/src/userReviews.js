import React from 'react';

function UserComment(props) {
  const { src, alt, username, date, content } = props;

  return (
    <li className="user-comment">
      <img src={src} alt={alt} className="profile-picture" />
      <div className="comment-details">
        <p className="username">{username}</p>
        <p className="date">{date}</p>
        <p className="content">{content}</p>
      </div>
    </li>
  );
}

export default UserComment;

import React from 'react';
import { createRoot } from 'react-dom/client';
import './index.css';

const root = createRoot(document.querySelector('#root'));

root.render(
  <React.StrictMode>
    <h1>Camphor</h1>
    <h4>LA Arts District hidden restaurant gem</h4>

    <div className="link">
      <a href="https://www.camphor.la/">Official Website</a>
    </div>

    <div className="header-img">
      <img
        src="https://res.cloudinary.com/the-infatuation/image/upload/c_scale,w_1200,q_auto,f_auto/cms/camphor/JakobLayman.Camphor_023"
        alt="camphor1"
      />
    </div>

    <div className="categories">
      <ul>
        <li>French</li>
        <li>Southeast Asian</li>
        <li>Arts District</li>
        <li>$$$</li>
      </ul>
    </div>

    <div className="paragraphs">
      <p>
        Have you ever felt like you were inside of a disco ball? That’s what
        happens in the bathroom at Camphor, a mostly French, occasionally
        Southeast Asian restaurant in the Arts District that’s as surreal as
        you’d expect. Mirrors cover every wall, reflecting back infinite
        versions of yourself. There’s a heated bidet and three different types
        of liquids for your hands (scented and unscented soap, plus a silky soft
        lotion). And almost everything is either gold or silver. The bathroom is
        a bit over-the-top; precious and extravagant in a way that can feel
        uninteresting, like a perfectly pretty flower or a person with a Leo
        moon.
      </p>
      <p>
        Camphor the restaurant works similarly. After one dinner, we described
        it to a friend as “shiny, expensive, and nice.” Which about sums it up.
        You’ll drink excellent cocktails infused with sage and spiced vanilla
        pineapple and eat soft, pungent cheeses. The word “exquisite” will
        probably spill out of your mouth. If you want someone to know you’re
        trying to impress them, come here to do it.
      </p>
    </div>

    <div className="img-container">
      <img
        src="https://res.cloudinary.com/the-infatuation/image/upload/c_fill,w_1200,ar_4:3,g_center,f_auto/cms/camphor/JakobLayman.Camphor_010"
        alt="camphor2"
      />
      <img
        className="camphor-3"
        src="https://res.cloudinary.com/the-infatuation/image/upload/c_fill,w_1200,ar_4:3,g_center,f_auto/cms/camphor/JakobLayman.Camphor_019"
        alt="camphor3"
      />
      <img
        src="https://res.cloudinary.com/the-infatuation/image/upload/c_fill,w_1200,ar_4:3,g_center,f_auto/cms/camphor/JakobLayman.Camphor_013"
        alt="camphor4"
      />
      <img
        src="https://res.cloudinary.com/the-infatuation/image/upload/c_fill,w_1200,ar_4:3,g_center,f_auto/cms/camphor/JakobLayman.Camphor_007"
        alt="camphor5"
      />
    </div>

    <div className="paragraphs">
      <p>
        If dining at hot, new restaurants is your sport of choice, you may feel
        a wave of déjà vu in the dining room. The space—very obviously—was once
        home to Nightshade, and décor-wise, not much has changed. There’s still
        that icy, jewelry box feel to it: velvet booths line the walls, marble
        tops tables, and meals arrive on antique serving ware. And the service
        is top-notch—drink orders are taken the moment you step in the door,
        food runners describe dishes in vivid detail, and if you happen to get
        the date wrong and arrive a week early (like we did once), the host will
        look for a way to seat you as if their life depends on it. You’re in
        good hands.
      </p>
      <p>
        But let’s go back to “mostly French, occasionally Southeast Asian” food.
        What does that mean? Well, 90% of Camphor’s menu is typical of what
        you’d find at an upscale French bistro: baguettes served with funky
        cheese, asparagus in béarnaise sauce, and peppery steak au poivre. It’s
        the kind of traditionally executed food that will please even the
        pickiest of grandfathers and corporate executives who haven’t tried
        something new since the first-generation iPod.
      </p>
    </div>

    <hr />

    <h2>Customer Reviews:</h2>

    <ul className="reviews">
      <li className="user-comment">
        <img
          src="https://www.scienceofpeople.com/wp-content/uploads/2016/03/woman_lip-touch_monroe-gaze.jpg"
          alt="user 1"
          className="profile-picture"
        />
        <div className="comment-details">
          <p className="username">amandacolls99</p>
          <p className="date">September 25 2023</p>
          <p className="content">
            Loved this place start to finish. French food is already in my book
            the goat, but this restaurant is a shooting star amongst LA fine
            dining.
          </p>
        </div>
      </li>
      <li className="user-comment">
        <img
          src="https://media.istockphoto.com/id/1471845315/photo/happy-portrait-or-business-woman-taking-a-selfie-in-office-building-for-a-social-media.webp?b=1&s=170667a&w=0&k=20&c=2-VGjlhPIjfj1I98HnA_qVM7TePchgVXe2y3TI65Y-0="
          alt="user 2"
          className="profile-picture"
        />
        <div className="comment-details">
          <p className="username">pattyf123</p>
          <p className="date">September 22 2023</p>
          <p className="content">
            I'm always hesitant to visit French restaurants in the States, but I
            thoroughly enjoyed my meals every time I've been here so far.
            Although on the more expensive end, I thought each dish was thought
            out and delicious.
          </p>
        </div>
      </li>
      <li className="user-comment">
        <img
          src="https://img.freepik.com/free-photo/portrait-happy-young-woman-looking-camera_23-2147892777.jpg"
          alt="user 3"
          className="profile-picture"
        />
        <div className="comment-details">
          <p className="username">lindsaymorris012</p>
          <p className="date">September 17 2023</p>
          <p className="content">
            Mom came to visit and had a truly memorable and delightful evening
            with family at Camphor LA. The lobster saffron risotto, scallops
            pasta, and steak sound like absolute must-tries. The attention to
            detail in the presentation and preparation, like the lobster bisque
            being poured at the table, really adds to the overall experience.
            It's fantastic to hear that the scallops were cooked to perfection,
            and the steak had the right balance of tenderness and flavor. The
            fact that you got to enjoy this meal while catching up with
            long-time friends and family makes it even more special. A Michelin
            star restaurant experience indeed!
          </p>
        </div>
      </li>
      <li className="user-comment">
        <img
          src="https://images.squarespace-cdn.com/content/v1/5c5a48b7809d8e364b16c2bf/1614918524858-4HA3SDC8ZWAJLNFZDBHB/NAB+Fun-2.jpg?format=500w"
          alt="user 4"
          className="profile-picture"
        />
        <div className="comment-details">
          <p className="username">alison443w</p>
          <p className="date">September 12 2023</p>
          <p className="content">
            Excellent service and phenomenal cuisine. Just a superb dining
            experience. Highly recommend, will definitely be back. 10/10. The
            scallop ravioli are insane: an absolute must.
          </p>
        </div>
      </li>
    </ul>

    <footer>© 2023 Camphor LA</footer>
  </React.StrictMode>
);
